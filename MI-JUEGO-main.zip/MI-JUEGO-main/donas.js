class Dona{
    dona=createSprite(200,300,20,20);
    dona.addImage(donaImg);
    dona.scale=0.02;
};